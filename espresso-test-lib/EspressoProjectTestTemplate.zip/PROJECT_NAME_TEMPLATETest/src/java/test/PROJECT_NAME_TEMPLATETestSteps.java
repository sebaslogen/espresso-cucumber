package PACKAGE_NAME_TEMPLATE.test;

import android.test.ActivityInstrumentationTestCase2;

import PACKAGE_NAME_TEMPLATE.DEFAULT_ACTIVITY;
import PACKAGE_NAME_TEMPLATE.R;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.assertion.ViewAssertions.doesNotExist;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;

/**
 * Tests steps for the tested activity.
 */
public class PROJECT_NAME_TEMPLATETestSteps extends ActivityInstrumentationTestCase2<DEFAULT_ACTIVITY> {
    
    // Holds the activity under test
    private DEFAULT_ACTIVITY mActivity;

    public PROJECT_NAME_TEMPLATETestSteps() {
        super(DEFAULT_ACTIVITY.class);
    }

    @After
    public void after() {
        if (mActivity != null) { // Close activity after each test scenario
            mActivity.finish();
        }
    }
/*
 * Basic examples of Cucumber step definitions using Espresso test instrumentation

    @Given("^I start My Activity$")
    public void i_start_my_activity() {
        mActivity = getActivity();
    }

    @Given("^I see \"(.+)\" screen$")
    public void i_see_screenName_screen(final String screenName) {
        onView(withId(R.id.my_screen_id)).check(matches(isDisplayed()));
    }

    @Given("^tested activity is closed$")
    public void tested_activity_is_closed() {
        if (! mActivity.isFinishing() ) {
            throw new IllegalArgumentException("Application is still running");
        }
    }
*/
}
